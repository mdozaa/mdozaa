#!/bin/bash
#MIGUEL PACHECO
#111453454
#CSE337 PROG1
if [ "$#" -ne 2 ]; then
  echo "src and dest dirs missing"
  exit 1
fi
function traverse() {
counter=0
declare -a filesCopied
for file in "$1"/*
do
  fileCount=$(ls "$(dirname "$file")" | wc -l)
  #echo $file
  #initial run is to get a count of how many c files there are in the directory
    if [ ! -d "${file}" ]; then
        #echo "$file is a file"
        if [ ${file##*.} == "c" ] || [ ${file##*.} == "C" ]; then
          counter=$((counter + 1))
          filesCopied+=("$file")
        fi

    else #encountered a folder
        #echo $counter
        #check to see if the current directory had more than 3
        if [ $counter -gt 3 ]; then
          for filestoReport in "${filesCopied[@]}"; do
            echo $(basename $filestoReport)
          done
          echo "There are more than 3 .C files in this directory. Press Y or y to continue."
          read continueInput
          if [ $continueInput == 'Y' ] || [ $continueInput == 'y' ]; then
            for copyFromPath in "${filesCopied[@]}"; do
              mv -v $copyFromPath $dest
              done
          fi
        else
          for copyFromPath in "${filesCopied[@]}"; do
              mv -v $copyFromPath $dest
              done
        fi
        #---------------------------------------------------------------
        counter=0
        #rootpath is $destDirectory
        #fullpath is "${file}"
        path=${file#${srcDirectory}}
        #echo "echoing $path"
        dest=$recordTracking
        dest="$dest$path"
        #echo "the new destination is: $dest"
        unset filesCopied
        mkdir -p $dest
        #echo "entering recursion with: ${file}"
        #entering the next subdirectory
        traverse "${file}"
    fi
done
  if [ $counter -gt 3 ]; then
          for filestoReport in "${filesCopied[@]}"; do
            echo $(basename $filestoReport)
          done
          echo "There are more than 3 .C files in this directory. Press Y or y to continue copying."
          read continueInput
          if [ $continueInput == 'Y' ] || [ $continueInput == 'y' ]; then
            for copyFromPath in "${filesCopied[@]}"; do
              mv -v $copyFromPath $dest
              done
          fi
        else
          for copyFromPath in "${filesCopied[@]}"; do
              mv -v $copyFromPath $dest
              done
        fi
}
function main() {
    traverse "$1"
}

#srcDirectory="/mnt/c/Users/MIGUEL/IdeaProjects/UNIXHW/project"
#dest="/mnt/c/Users/MIGUEL/IdeaProjects/UNIXHW/project_bkup"

srcDirectory=$1

if [ ! -d $srcDirectory ]; then
  echo "$srcDirectory not found"
  exit 0
fi

dest=$2
recordTracking=$dest
mkdir -p $dest
main $srcDirectory