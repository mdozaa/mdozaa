#!/bin/bash
#MIGUEL PACHECO
#111453454
#CSE337 PROG3
if [ "$#" -lt 1 ]; then
  echo "data file missing"
  exit 1
fi
#numerator WHEN WEIGHT PROVIDED == NUMBER OF QUIZZES TAKEN
function numerator() {
  declare -a qSArray3=("${!1}")
  #echo "${qSArray3[@]}"
  declare -a w3=("${!2}")
  #echo "${w3[@]}"
  maxTimesToAdd=${#quizScores[@]}
  toAddSum=0
  indexNum=0 #to access the weight multiplier
  for num in "${qSArray3[@]}"; do
    #echo $num
    #echo ${weight[indexnum]}
    associatedWeight="${w3[indexNum]}"
    weighted=$((associatedWeight * num))
    #echo $weighted
    toAddSum=$((weighted + toAddSum))
    indexNum=$((indexNum + 1))
    #echo $toAddSum
  done
  echo $toAddSum
}

function denominator() {
  declare -a qSArray2=("${!1}")
  declare -a wArray2=("${!2}")
  denomSum=0
  maxTimesToAdd=${#qSArray2[@]}
  indexNum=0
  while [ $indexNum -lt $maxTimesToAdd ]; do
    denomSum=$((wArray2[indexNum] + denomSum))
    indexNum=$((indexNum + 1))
  done
  echo $denomSum
}

function getFinalResult() {
  declare -a qSArray=("${!1}")
  declare -a wArray=("${!2}")
  #echo "${qSArray[@]}"
  #echo "${wArray[@]}"

  nResult=$(numerator qSArray[@] wArray[@])
  dResult=$(denominator qSArray[@] wArray[@])
  #echo $nResult $dResult

  finalResult=$((nResult / dResult))
  echo $finalResult
}

function intakeFile() {
  #intake the file
  input=$1
  if [ -f $input ]; then
    sed -e '$a\' $input > copy.txt
    input="copy.txt" #delete this later
    while read line; do
      currentLine="$line"
      # $currentLine
      #currentline=$line
      #echo $counter

      if [[ $currentLine =~ (^[a-zA-Z]*[,]) ]]; then
        #echo "woah"
        continue
      else
        #echo "this does not start with letters"
        #echo "student array result holder built:" "${studentResults[@]}"
        #echo "these are numbers"
        #separate the numbers by the delimeter
        IFS=','
        read -ra toAdd3 <<< "$line"
        #use this to skip the first element
        #remember, first element is ID
        skipper=0
        idNum=0
        for num in "${toAdd3[@]}"; do
          if [ $skipper != 0 ]; then
            quizScores+=("$num")
          else
            idNum=$num
            studentIDs+=("$idNum")
          fi
          skipper=$((skipper + 1))
        done

        maxLength2=${#quizScores[@]}

        #LESS
        if [ ${#weights[@]} -lt ${#quizScores[@]} ]; then
          #echo "there were less arguments provided than quiz scores"
          weightFillerIndex=${#weights[@]}
          #echo "$weightFillerIndex"
          while [ "$weightFillerIndex" -lt "$maxLength2" ]; do
            weights+=("${weights[$((weightFillerIndex-1))]}")
            weightFillerIndex=$((weightFillerIndex + 1))
          done
          #weights is now sanitized
          #echo "${weights[@]}"
          numForLine1=$(numerator quizScores[@] weights[@])
          denomForLine1=$(denominator quizScores[@] weights[@])
          getFinalResult1=$((numForLine1 / denomForLine1))
          studentResults+=("$getFinalResult1")
          #echo "inputting" "$getFinalResult1"

        #SAME
        elif [ ${#weights[@]} == ${#quizScores[@]} ]; then
          #echo "the arguments provided are equal to the amount of quiz scores"
          numForLine2=$(numerator quizScores[@] weights[@])
          denomForLine2=$(denominator quizScores[@] weights[@])
          getFinalResult2=$((numForLine2 / denomForLine2))
          studentResults+=("$getFinalResult2")
          #echo "inputting" "$getFinalResult2"

        else
          #echo "the arguments provided are greater than the amount of quiz scores"
          declare -a trimmedWeight
          caIndexer=0
          while [ $caIndexer -lt $maxLength2 ]; do
            trimmedWeight+=("${weights[$caIndexer]}")
            caIndexer=$((caIndexer + 1))
          done
          numForLine=$(numerator quizScores[@] trimmedWeight[@])
          denomForLine=$(denominator quizScores[@] trimmedWeight[@])
          getFinalResult=$((numForLine / denomForLine))
          studentResults+=("$getFinalResult")
          # "inputting" "$getFinalResult"
        fi
      fi
    done < <(tr -d '\r' < "$input")
  fi
}

#-------------------------------------------------------------------------
#Task: clean up the data retrieved from the command line so that we can use the functions above
#first argument is always going to be the data file, so lets skip that when we're making the weight
declare -a weights
argsGiven=$#
#echo "args" $argsGiven
argCounter=2 #start at 2 because 1 is the text file
while [ $argCounter -lt $((argsGiven+1)) ]; do
  #build the command; this is to retrieve the argument
  argBuilder="\$$argCounter"
  weights+=("$(eval echo $argBuilder)")
  argCounter=$((argCounter + 1))
done
#Just created weights from arguments
declare -a studentResults
declare -a studentIDs
intakeFile "$1"
#echo "the student results are: " "${studentResults[@]}"
resultIterator=0
#echo "Student ID : Result"
while [ $resultIterator -lt ${#studentResults[@]} ]; do
  echo "${studentIDs[$resultIterator]}" " : " "${studentResults[$resultIterator]}"
  resultIterator=$((resultIterator + 1))
done
rm "copy.txt"
#-------------------------------------------------------------------------

