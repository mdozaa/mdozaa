#!/bin/bash
#MIGUEL PACHECO
#111453454
#CSE337 PROG4
#intake:
#./prog4.sh <directory/path/here>
#that means... $1 is a path

function intakeFile() {
  #intake the file
  input=$1
  if [ -f $input ]; then
    sed -e '$a\' $input > copy.txt
    input="copy.txt" #delete this later
    declare -a accumulatedPoints
    while read line; do
      currentLine="$line"
      if [[ $currentLine =~ (^[a-zA-Z]*[,]) ]]; then
        #echo "woah"
        continue
      else
        #Code underneath IS FOR WHEN THE LINE STARTS WITH A NUMBER
        IFS=','
        read -ra toAdd3 <<< "$line"
        #use this to skip the first element - remember, first element is ID
        skipper=0
        idNum=0
        for pointsReceived in "${toAdd3[@]}"; do
          if [ $skipper != 0 ]; then
            accumulatedPoints+=("$pointsReceived")
          else
            idNum=$pointsReceived
            studentIDs+=("$idNum")
          fi
          skipper=$((skipper + 1))
        done

        #add up the numbers acquired in accumulatedPoints
        sumPoints=0
        for num in "${accumulatedPoints[@]}"; do
          sumPoints=$((sumPoints + num))
        done

        getLetterGrade=$((sumPoints * 2))

        if [ 93 -lt $getLetterGrade ] && [ $getLetterGrade -lt 100 ]; then
          studentResults+=("A")
        fi
        if [ 80 -lt $getLetterGrade ] && [ $getLetterGrade -lt 93 ]; then
          studentResults+=("B")
        fi
        if [ 65 -lt $getLetterGrade ] && [ $getLetterGrade -lt 80 ]; then
          studentResults+=("C")
        fi
        if [ $getLetterGrade -lt 65 ]; then
          studentResults+=("D")
        fi
      fi
    done < <(tr -d '\r' < "$input")
  fi
}
#-------------------------------------------------------------------------
declare -a studentResults
declare -a studentIDs
pathProvided=$1

for File in "$pathProvided"/*; do

  if [ -f "$File" ]; then
        #echo "$file is a file"
        if [ ${File##*.} == "txt" ] || [ ${File##*.} == "TXT" ]; then
          intakeFile $File
        fi
  fi
done
#echo "the student results are: " "${studentResults[@]}"
resultIterator=0
while [ $resultIterator -lt ${#studentResults[@]} ]; do
  echo "${studentIDs[$resultIterator]}" " : " "${studentResults[$resultIterator]}"
  resultIterator=$((resultIterator + 1))
done
rm "copy.txt"
#-------------------------------------------------------------------------