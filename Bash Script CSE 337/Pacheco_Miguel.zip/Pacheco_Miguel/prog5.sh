#!/bin/bash
#MIGUEL PACHECO
#111453454
#CSE337 PROG5
if [ "$#" -ne 2 ]; then
  echo "input file and dictionary missing"
  exit 1
fi
function intakeDictionary() {
  #intake the dictionary
  input=$1
  if [ -f $input ]; then
    sed -e '$a\' $input > copy.txt
    input="copy.txt" #delete this later

    while read line; do
      fourDict+=("$line")
    done < <(tr -d '\r' < "$input")
    rm "copy.txt"
    #echo "${fourDict[@]}"
  fi
}
function intakeFile() {
  input=$1
  if [ -f $input ]; then
    sed -e '$a\' $input > copy.txt
    input="copy.txt" #delete this later
    grep -Eo "\<[[:alpha:]]{4}\>" $input > foundwords.txt
    #echo "ok"
    rm "copy.txt"
    input="foundwords.txt"
    sed -e '$a\' $input > copyFW.txt
    input="copyFW.txt"
    rm "foundwords.txt"
    while read line; do
      fourLetterWords+=("$line")
    done < <(tr -d '\r' < "$input")
    rm "copyFW.txt"
  fi
}
declare -a fourDict
declare -a fourLetterWords
if [ -f "$1" ]; then
  intakeFile "$1"
else
  echo "$1 is not a file"
  exit 1
fi
#intakeDictionary "/mnt/c/Users/MIGUEL/IdeaProjects/UNIXHW/fourLetterDict.txt"
#intakeFile "/mnt/c/Users/MIGUEL/IdeaProjects/UNIXHW/prob5-sample.txt"
if [ -f "$2" ]; then
  intakeDictionary "$2"
else
  echo "$2 is not a file"
  exit 1
fi

for wordToSearch in "${fourLetterWords[@]}"; do
  if [[ " ${fourDict[*]} " == *"$wordToSearch"* ]]; then
    continue
  else
    echo $wordToSearch
  fi
done