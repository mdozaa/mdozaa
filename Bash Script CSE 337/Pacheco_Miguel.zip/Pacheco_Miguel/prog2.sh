#!/bin/bash
#MIGUEL PACHECO
#111453454
#CSE337 PROG2
if [ "$#" -ne 1 ]; then
  echo "Data file or output file not found"
  exit 1
fi
#for testing
input=$1

#for actual use
#input=$1
if [ -f $input ]; then
  #intake line, sort by delimeter
  #keep track of line number
  #adds \n at EOF so that read works properly
  echo >> "$(basename $input)"
  maxArrayLength=0
  declare -a sumArray

  #find the longest length line---------------------------------------
  while read line; do
    #echo $maxArrayLength
    #echo "$line"
    if [[ $line =~ [0-9]*[\;] ]]; then
      #echo "found semi:"
      IFS=';'
      read -ra toAdd <<< "$line"
      checkMax=${#toAdd[@]}
      if [ "$checkMax" -gt "$maxArrayLength" ]; then
        maxArrayLength=$checkMax
      fi
    fi

    if [[ $line =~ [0-9]*[:] ]]; then
      #echo "found colon"
      IFS=':'
      read -ra toAdd2 <<< "$line"
      checkMax2=${#toAdd2[@]}
      if [ "$checkMax2" -gt "$maxArrayLength" ]; then
        maxArrayLength=$checkMax2
      fi
    fi

    if [[ $line =~ [0-9]*[,] ]]; then
      #echo "found comma"
      IFS=','
      read -ra toAdd3 <<< "$line"
      checkMax3=${#toAdd3[@]}
      if [ "$checkMax3" -gt "$maxArrayLength" ]; then
        maxArrayLength=$checkMax3
      fi
    fi
  done < <(tr -d '\r' < "$input")
  #-------------------------------------------------------------------

  #making a blank array of the largest length-------------------------
  populatorIterator=0
  while [ $populatorIterator -lt $maxArrayLength ]; do
    sumArray+=(0)
    populatorIterator=$((populatorIterator + 1))
    done
  #-------------------------------------------------------------------
  
  #iterate over the file's lines to add each number into its respective column
  while read line; do
    if [[ $line =~ [0-9]*[\;] ]]; then
      #echo "found semi:"
      IFS=';'
      read -ra toAdd <<< "$line"
      indexForSumArray=0
      for num in "${toAdd[@]}"; do
        sumArray[indexForSumArray]=$((sumArray[indexForSumArray] + num))
        indexForSumArray=$((indexForSumArray + 1))
        done
    fi

    if [[ $line =~ [0-9]*[,] ]]; then
      #echo "found semi:"
      IFS=','
      read -ra toAdd <<< "$line"
      indexForSumArray2=0
      for num in "${toAdd[@]}"; do
        sumArray[indexForSumArray2]=$((sumArray[indexForSumArray2] + num))
        indexForSumArray2=$((indexForSumArray2 + 1))
        done
    fi

    if [[ $line =~ [0-9]*[:] ]]; then
      #echo "found semi:"
      IFS=':'
      read -ra toAdd <<< "$line"
      indexForSumArray3=0
      for num in "${toAdd[@]}"; do
        sumArray[indexForSumArray3]=$((sumArray[indexForSumArray3] + num))
        indexForSumArray3=$((indexForSumArray3 + 1))
        done
    fi
  done < <(tr -d '\r' < "$input")
  #----------------------------------------------------------------------------

  #delete the contents of the input file---------------------------------------
  true > $input
  #----------------------------------------------------------------------------

  #Output the array into the file----------------------------------------------
  #Counter = 1 because columns start at 1, not 0
  counter=1
  for num in "${sumArray[@]}"; do
        echo "Col $counter : $num" >> $(basename $input)
        counter=$((counter + 1))
        done
  #----------------------------------------------------------------------------

else
  echo "$(basename $input) not found"
  fi